import 'dart:io';
 enum TokenType
  {
    keyword,
    string,
    intager,
    identifier,
    symbol
  }
class Token
{
 
   Token(String Path)
   {
     File f=File(Path);

     

   }
   
}